// Header scroll
window.onscroll = function () { scrollFunction() };

function scrollFunction() {
    const header = document.getElementById("main-header");

    if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
        header.classList.add("scrolled");
    } else {
        header.classList.remove("scrolled");
    }
}


// Random Quotes
const quotes = [
    '"It does not do to dwell on dreams and forget to live."',
    '"After all this time? Always."',
    '"I solemnly swear that I am up to no good."',
    '"Happiness can be found even in the darkest of times, if one only remembers to turn on the light."',
    '"It takes a great deal of bravery to stand up to our enemies, but just as much to stand up to our friends."',
    '"The truth. It is a beautiful and terrible thing, and should therefore be treated with great caution."',
    '"Fear of a name only increases fear of the thing itself."',
    '"If you want to know what a man’s like, take a good look at how he treats his inferiors, not his equals."',
    '"It matters not what someone is born, but what they grow to be."',
    '"Your devotion is nothing more than cowardice. You would not be here if you had anywhere else to go."'
];

function displayQuote(index) {
    document.getElementById('quote-text').innerText = quotes[index];
}

window.onload = function () {
    const today = new Date();
    displayQuote(today.getDay() % quotes.length);
};

function newQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    document.getElementById('quote-text').innerText = quotes[randomIndex];
}


// Hogwarts quiz
document.getElementById('submit-hogwarts-quiz').addEventListener('click', function () {
    let score = 0;
    const totalQuestions = 20;
    const answers = document.querySelectorAll('input[type="radio"]:checked');

    // Loop through the selected answers and check for correctness
    answers.forEach(answer => {
        if (answer.value === 'correct') {
            score++;
        }
    });

    // Display the result in the quiz-result div
    const resultDiv = document.getElementById('hogwarts-quiz-result');
    resultDiv.innerHTML = `
        <h3>Your Score: ${score} / ${totalQuestions}</h3>
    `;

    // Additional feedback based on score
    if (score === totalQuestions) {
        resultDiv.innerHTML += `<p>Perfect score! You truly know everything about Hogwarts School!</p>`;
    } else if (score >= 15) {
        resultDiv.innerHTML += `<p>Great job! You're well on your way to being a Hogwarts expert!</p>`;
    } else if (score >= 10) {
        resultDiv.innerHTML += `<p>Good effort! Keep learning about the magic of Hogwarts!</p>`;
    } else {
        resultDiv.innerHTML += `<p>Keep going! There’s so much more to discover about Hogwarts.</p>`;
    }


});
















